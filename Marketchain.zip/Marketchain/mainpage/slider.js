var figure=document.getElementById("figure");
var infowrap=document.getElementById("infowrap");
var left=["0%","-100%","-200%","-300%"];
var i=0;
var time=4000;
var freezingTime=2000;
var nextSlide,prevslide;
var directionleft=true;
nextSlide=1;
prevslide=-1;
figure.style.left=left[0];
infowrap.style.left=left[0];
var isPaused=false;
var stop=false;
setInterval("Slide();",time);
function Slide(){
   if(!isPaused&&!stop){
    if(directionleft){
        if(i<left.length-1){
            i++;
        }
        else {
            directionleft=false;
            i--;
        }
    }
    else{
        if(i>0){
            i--;
        }
        else {
            directionleft=true;
            i++;
        }
    }  
    
    figure.style.left=left[i];
    infowrap.style.left=left[i];
    nextSlide=i+1;
    prevslide=i-1;
    /*console.clear();
    console.log(directionleft+" "+i);*/
   }
    
}

function SlideL(){

    if(prevslide>=0){
        figure.style.left=left[prevslide];
        infowrap.style.left=left[prevslide];
        prevslide--;
        nextSlide--;
        i=(prevslide+nextSlide)/2;
        isPaused=true;
        setTimeout("Pause();",freezingTime);
    }
    else {
        //console.log("limit"+directionleft);
        directionleft=true;
    }
    //console.log(i);
}
function SlideR(){
    if(nextSlide<left.length){
        figure.style.left=left[nextSlide];
        infowrap.style.left=left[nextSlide];
        prevslide++;
        nextSlide++;
        i=(prevslide+nextSlide)/2;
        isPaused=true;
        setTimeout("Pause();",freezingTime);
    }
    else {
        directionleft=false;
        //console.log("limit"+directionleft);
    }
    //console.log(i);
}
function Pause(){ 
    isPaused=false;
}
function PauseBtn(){
    stop=!stop;
}