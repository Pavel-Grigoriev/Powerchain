$("nav ul li:nth-child(1) a").addClass("active");
$(".hide ul li:nth-child(1)").addClass("active");
$("nav").addClass("fullsize");
$(".spaceup").addClass("fullsize");
$(window).scroll(function () {
    if ($(this).scrollTop() <= 200) {
        $("nav").addClass("fullsize");
        $(".spaceup").addClass("fullsize");
    }
    else {
        $("nav").removeClass("fullsize");
        $(".spaceup").removeClass("fullsize");
    }
});
$("#bars").on('click', function () {
    $("#bars").toggleClass("clicked");
    $(".hide").toggleClass("active");
    $("#search").removeClass("clicked");
    $(".list").removeClass("active");
});
$("#search").on('click', function () {
    $("#search").toggleClass("clicked");
    $(".list").toggleClass("active");
    $("#bars").removeClass("clicked");
    $(".hide").removeClass("active");
});
$(document).ready(function () {
    $('.hide ul li').bind('touchstart touchend', function (e) {
        e.preventDefault();
        $(this).toggleClass('hover_effect');
    });
    $('.types li').bind('touchstart touchend', function (e) {
        e.preventDefault();
        $(this).toggleClass('hover_effect');
    });
    $('footer .fa').bind('touchstart touchend', function (e) {
        e.preventDefault();
        $(this).toggleClass('hover_effect');
    });
    $('.box .txtBx').on('click', function (e) {
        e.preventDefault();
        $(this).toggleClass('hover_effect');
    });
    $('#play').on('click', function (e) {
        e.preventDefault();
        $(this).toggleClass('hover_effect');
    });
    $(".title").click(function () {
        $('html,body').animate({
            scrollTop: $(".spaceup").offset().top
        }, 'slow');
    });
    $(".linkarea").click(function () {
        $('html,body').animate({
            scrollTop: $(".spacedown").offset().top
        }, 'slow');
    });
});
